<template>
  <div id="app">
    <Home :menu-opened="menuOpened" :applied-prop="appliedProp" />
    <Sidebar :menu-opened="menuOpened" :applied-prop="appliedProp"/>
  </div>
</template>
<script>
import Home from '../components/Home.vue';
import Sidebar from '../components/Sidebar.vue';

export default {
  data() {
    return {
      menuOpened: false,
      appliedProp: {
        buttons: {
          btn1: 'bg-blue-500 text-white font-bold py-2 px-4 rounded',
          btn2: 'bg-transparent text-blue-700 font-semibold py-2 px-4 border border-blue-500 rounded'
        },
        color: {
          primary: '#2C3E50',
          secondary: '#2C3E50'
        },
        font: {
          fontStyle: 'sans'
        },
        advanced: {
          modalBgColor: '#FFFFFF',
          fontSize: 16,
          overlayColor: '#BEE3F8'
        },
        name: 'Dnyaneshwar Kadam (VueJs Developer)'
      },
    };
  },
  components: {
    Home,
    Sidebar,
  },
  beforeCreate() {
    // alert('beforCreate hook has been called');
  },
  created(){
    // alert('Create hook has been called');
  },
  beforeMount() {
    // alert('Create hook has been called');
  },
  async mounted() {},
  methods: {}
}
</script>
