import Vue from "vue";
import Router from "vue-router";

Vue.use(Router);

const router = new Router({
  mode: "history",
  linkExactActiveClass: "vue-school-active-class",
  routes: [
    {
      path: "/",
      name: "dashboard",
      component: () => import("./views/Dashboard")
    },
    {
      path: "/404",
      alias: "*",
      name: "notFound",
      component: () => import("./views/NotFound")
    }
  ]
});

export default router;
