<template>
  <section>
    <aside :class="{ 'show-hide-menu': !menuOpened }" class="mob border-r bg-white border-gray-300 flex whitespace-no-wrap flex-none z-50">
      <XIcon class="absolute right-0" @click="$parent.menuOpened = !$parent.menuOpened"/>
      <nav class="w-full pl-12">
        <div class="mx-auto flex py-4 font-bold text-lg border-b border-gray-300">
          Theme Editor
        </div>
        <div @click="menuIconClicked('color')" class="mx-auto flex py-4 font-bold border-b border-gray-300 cursor-pointer">
          Color <ChevronRightIcon id="color-title" class="mx-4 transform" />
        </div>
        <div id="color" class="flex-col toggle-up border-b border-gray-300">
          <div class="w-1/2 flex-col mr-2">
            <p>Primary Color</p>
            <input id="primary" class="border border-gray-300 font-bold py-2 px-4 w-32 rounded" data-jscolor="{value:'#FF61A5', alpha:0.50}" @change="changeColor($event, 'primary')">
          </div>
          <div class="w-1/2 mt-4">
            <p>Secondary Color</p>
            <input id="secondary" class="border border-gray-300 font-bold py-2 px-4 w-32 rounded" data-jscolor="{value:'#DC70FF', alpha:0.50}" @change="changeColor($event, 'secondary')">
          </div>
        </div>
        <div @click="menuIconClicked('font')" class="mx-auto flex py-4 font-bold border-b border-gray-300 cursor-pointer">
          Font <ChevronRightIcon id="font-title" class="mx-4 transform" />
        </div>
        <div id="font" class="toggle-up border-b border-gray-300">
          <div @click="menuIconClicked('fontStyle')" class="border border-gray-300 flex font-semibold justify-center mx-auto mt-4 py-2 w-2/3">
            Font Style: {{ appliedProp.font.fontStyle }}
          </div>
          <div id="fontStyle" class="flex-col toggle-up mx-auto py-2 w-2/3 cursor-pointer">
            <div class="w-full text-center text-lg" @click="menuIconClicked('fontStyle')" >
              <p class="font-sans" @click="$parent.appliedProp.font.fontStyle = 'sans'">sans</p>
              <p class="font-arial" @click="$parent.appliedProp.font.fontStyle = 'arial'">arial</p>
              <p class="font-mano" @click="$parent.appliedProp.font.fontStyle = 'mano'">mono</p>
              <p class="font-roboto" @click="$parent.appliedProp.font.fontStyle = 'roboto'">roboto</p>
              <p class="font-serif" @click="$parent.appliedProp.font.fontStyle = 'serif'">serif</p>
            </div>
          </div>
        </div>
        <div @click="menuIconClicked('button')" class="mx-auto flex py-4 font-bold border-b border-gray-300 cursor-pointer">
          Buttons <ChevronRightIcon id="button-title" class="mx-4 transform" />
        </div>
        <div id="button" class="toggle-up border-b border-gray-300">
          <div v-for="(btn, index) in btnCss" :key="index" @click="changeBtn(btn)" class="my-2 flex justify-around">
            <span>Set {{ index+1 }}: </span>
            <button :class="btn.btn1" >
              Button
            </button>
            <button :class="btn.btn2">
              Button
            </button>
          </div>
        </div>
        <div @click="menuIconClicked('advanced')" class="mx-auto flex py-4 font-bold border-b border-gray-300 cursor-pointer">
          Advanced <ChevronRightIcon id="advanced-title" class="mx-4 transform" />
        </div>
        <div id="advanced" class="toggle-up border-b border-gray-300">
          <div class="w-1/2 flex-col mr-2 my-2">
            <h2 class="font-semibold text-left">Input</h2>
            <h4 class="text-left text-xs">Input text field style</h4>
            <div @click="menuIconClicked('fontStyle')" class="border border-gray-300 flex font-semibold justify-center mx-auto mt-4 py-2">
              Outline
            </div>
          </div>
          <div class="w-1/2 flex-col mt-4 my-2">
            <h2 class="font-semibold text-left">Modal Background Color</h2>
            <h4 class="text-left text-xs">Background color for modal window</h4>
            <input id="modalBgColor" class="border border-gray-300 font-bold my-2 py-2 px-4 w-32 rounded" data-jscolor="{value:'#FFFFFF', alpha:1.00}" @change="changeAdvColor($event, 'modalBgColor')">
          </div>
          <div class="mt-4 my-2">
            <h2 class="font-semibold text-left">Modal border radius</h2>
            <h4 class="text-left text-xs">Border radius for modal window</h4>
            <div class="flex">
              <div @click="decreseFontSize()" class="h-5 w-1/3 mb-6 absolute mt-2" />
              <div @click="increaseFontSize()" class="h-5 w-1/3 mb-6 absolute right-0 mr-16 mt-2" />
              <div class="absolute h-3 w-3 mt-3 bg-black rounded-full" :style="`left: ${fontScroller}px`" />
              <div class="h-5 w-4/5 mb-6 border-b-2 border-gray-300" />
              <span class="m-1">{{ appliedProp.advanced.fontSize }}px</span>
            </div>
          </div>
          <div class="w-1/2 my-2">
            <h2 class="font-semibold text-left">Overlay Color</h2>
            <h4 class="text-left text-xs">Color of background overlay for embedded flow</h4>
            <input id="overlayColor" class="border border-gray-300 font-bold my-2 py-2 px-4 w-32 rounded" data-jscolor="{value:'#BEE3F8', alpha:1.00}" @change="changeAdvColor($event, 'overlayColor')">
          </div>
        </div>
        <div class="bg-white bottom-0 py-8 flex justify-end">
          <button @click="undoChanges()" class="bg-transparent text-blue-700 font-semibold py-2 px-4 border border-blue-500 rounded">
            Undo all
          </button>
          <button @click="submitInfo()" class="bg-purple-700 hover:bg-purple-900 text-white font-bold py-2 px-4 rounded mx-4" >
            Save
          </button>
        </div>
      </nav>
    </aside>
  </section>
</template>

<script>
import { XIcon, ChevronRightIcon } from "vue-feather-icons";
import axios from "axios";

export default {
  name: 'Sidebar',
  components: {
    XIcon,
    ChevronRightIcon
  },
  data() {
    return {
      url: 'https://e8e67cee3540e96594a791e23ad056d6.m.pipedream.net',
      fontScroller: 105,
      btnCss: [
        {
          btn1: 'bg-blue-500 text-white font-bold py-2 px-4 rounded',
          btn2: 'bg-transparent text-blue-700 font-semibold py-2 px-4 border border-blue-500 rounded'
        },
        {
          btn1: 'bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-full',
          btn2: 'bg-transparent hover:bg-red-500 text-red-700 font-semibold hover:text-white py-2 px-4 border border-red-500 hover:border-transparent rounded-full'
        },
        {
          btn1: 'bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-full',
          btn2: 'bg-transparent hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded-full'
        },
        {
          btn1: 'bg-green-300 hover:bg-green-400 text-green-800 font-bold py-2 px-4 rounded-t-full',
          btn2: 'bg-green-300 hover:bg-green-400 text-green-800 font-bold py-2 px-4 rounded-b-full'
        },
        {
          btn1: 'bg-orange-500 text-white font-bold py-2 px-4 rounded',
          btn2: 'bg-transparent text-orange-700 font-semibold py-2 px-4 border border-orange-500 rounded'
        },
        {
          btn1: 'bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded-l',
          btn2: 'bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded-r'
        },
      ]
    };
  },
  props: {
    menuOpened: {
      type: Boolean,
      default: false
    },
    appliedProp: {
      type: Object,
    }
  },
  computed: {},
  mounted() {},
  methods: {
    changeBtn(btn) {
      this.$parent.appliedProp.buttons.btn1 = btn.btn1;
      this.$parent.appliedProp.buttons.btn2 = btn.btn2;
    },
    changeColor(event, id) {
      this.$parent.appliedProp.color.[id] = event.target.value;
    },
    changeAdvColor(event, id) {
      this.$parent.appliedProp.advanced.[id] = event.target.value;
    },
    decreseFontSize() {
      if (this.appliedProp.advanced.fontSize >= 10) {
        this.$parent.appliedProp.advanced.fontSize = this.appliedProp.advanced.fontSize - 2;
        this.fontScroller = this.fontScroller - 15;
      }
    },
    increaseFontSize() {
      if (this.appliedProp.advanced.fontSize <= 34) {
        this.$parent.appliedProp.advanced.fontSize = this.appliedProp.advanced.fontSize + 2;
        this.fontScroller = this.fontScroller + 15;
      }
    },
    menuIconClicked(id) {
      const element = document.getElementById(id);
      const element2 = document.getElementById(id+'-title');
      if(element.classList.contains('toggle-down')){
        element.classList.remove('toggle-down');
        element.classList.add('toggle-up');
        element2.classList.remove('rotate-90');
      } else if(element.classList.contains('toggle-up')){
        element.classList.remove('toggle-up');
        element.classList.add('toggle-down');
        element2.classList.add('rotate-90');
      }
    },
    submitInfo() {
      axios.post(this.url, this.appliedProp)
        .then((res) => {
          alert('Your data has been submitted successfully','res.data.success = ',res.data.success)
          return true;
        })
        .catch((error) => {
          console.warn(error);
        });
    },
    undoChanges(){
      this.$parent.appliedProp = {
        buttons: {
          btn1: 'bg-blue-500 text-white font-bold py-2 px-4 rounded',
          btn2: 'bg-transparent text-blue-700 font-semibold py-2 px-4 border border-blue-500 rounded'
        },
        color: {
          primary: '#2C3E50',
          secondary: '#2C3E50'
        },
        font: {
          fontStyle: 'sans'
        },
        advanced: {
          modalBgColor: '#FFFFFF',
          fontSize: 16,
          overlayColor: '#BEE3F8'
        },
        name: 'Dnyaneshwar Kadam (VueJs Developer)'
      }
    },
  },
};
</script>
<style lang="postcss" scoped>
/* stylelint-disable */
aside {
  position: fixed;
  height: 100%;
  top: 0;
  left: 0;
  will-change: transform;
  width: 324px;
  transform: translate3d(0, 0, 0);
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: auto;

  &.mob {
    margin-left: 0;
  }

  &.hide-menu {
    transform: translate3d(-100%, 0, 0);
  }
}
.show-hide-menu {
  transform: translate3d(-100%, 0, 0);
  -webkit-transform: translate3d(-100%, 0, 0);
  transform: translate3d(-100%, 0, 0);
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
}
.modal-backdrop {
  backdrop-filter: saturate(180%) blur(2px);
  background: #00000080;
}
.toggle-up {
  height: 0;
  opacity: 0;
  transition: opacity 0.3s;
  visibility: hidden;
}
.toggle-down {
  height: auto;
  opacity: 1;
  transition: opacity 0.3s;
  visibility: visible;
}
</style>
