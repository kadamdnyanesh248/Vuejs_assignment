<template>
  <section class="px-4 min-h-screen" :class="`font-${appliedProp.font.fontStyle}`" :style="`background-color: ${appliedProp.advanced.overlayColor}`">
    <MenuIcon class="absolute mx-4 my-2 left-0" @click="$parent.menuOpened = !$parent.menuOpened"/>
    <section class="min-h-screen">
      <div class="flex flex-wrap -mx-4 justify-around h-screen">
        <div class="w-full h-full sm:w-1/2 lg:w-1/3 px-8 py-20">
          <div class="h-full block px-4 py-6 shadow-md hover:shadow-xl rounded-lg overflow-hidden" :style="`background-color: ${appliedProp.advanced.modalBgColor}`">
            <h2 class="my-2 font-bold text-left">Upload a photo ID</h2>
            <h4 class="my-2 text-left">We require a photo of government ID to verify your identity.</h4>
            <h4 class="mt-4 mb-2 font-bold">Choose one of the following option</h4>
            <div class="flex justify-around px-2">
              <div class="w-1/3">
                <img src="@/assets/images/licence1.svg" class="border border-gray-300 p-3" alt="licence1">
                <span>Driver Licence</span>
              </div>
              <div class="w-1/3 mx-2">
                <img src="@/assets/images/licence1.svg" class="border border-gray-300 p-3" alt="licence1">
                <span>National ID</span>
              </div>
              <div class="w-1/3">
                <img src="@/assets/images/licence1.svg" class="border border-gray-300 p-3" alt="licence1">
                <span>Passport</span>
              </div>
            </div>
          </div>
        </div>
        <div class="w-full h-full sm:w-1/2 lg:w-1/3 px-8 py-20">
          <div class="h-full block px-4 py-6 shadow-md hover:shadow-xl rounded-lg overflow-hidden" :style="`background-color: ${appliedProp.advanced.modalBgColor}; color: ${appliedProp.color.secondary}`">
            <h2 class="my-2 font-bold text-left" :style="`font-size: ${appliedProp.advanced.fontSize}px; color: ${appliedProp.color.primary}`">Upload a photo ID</h2>
            <h4 class="my-2 text-left">We require a photo of government ID to verify your identity.</h4>
            <h4 class="mt-4 mb-2 font-bold">Choose one of the following option</h4>
            <div class="flex justify-around px-2">
              <div class="w-1/3">
                <img src="@/assets/images/licence1.svg" class="border border-gray-300 p-3" alt="licence1">
                <span>Driver Licence</span>
              </div>
              <div class="w-1/3 mx-2">
                <img src="@/assets/images/licence1.svg" class="border border-gray-300 p-3" alt="licence1">
                <span>National ID</span>
              </div>
              <div class="w-1/3">
                <img src="@/assets/images/licence1.svg" class="border border-gray-300 p-3" alt="licence1">
                <span>Passport</span>
              </div>
            </div>
          </div>
        </div>
        <div class="w-full h-full sm:w-1/2 lg:w-1/3 px-8 py-20">
          <div class="h-full block px-4 py-6 shadow-md hover:shadow-xl rounded-lg overflow-hidden" :style="`background-color: ${appliedProp.advanced.modalBgColor}; color: ${appliedProp.color.secondary}`">
            <h2 class="my-2 font-bold text-left" :style="`font-size: ${appliedProp.advanced.fontSize}px; color: ${appliedProp.color.primary}`">Driver Licence</h2>
            <h4 class="my-2 text-left">Take a clear photo of the back of your licence</h4>
            <div class="flex justify-around p-10">
              <img src="@/assets/images/card.png" class="p-3 w-1/2" alt="licence1">
            </div>
            <button :class="appliedProp.buttons.btn1"  class="w-full">
              <CameraIcon class="text-white mx-auto"/>
            </button>
            <button :class="appliedProp.buttons.btn2" class="w-full mt-2">
              Button
            </button>
            <h4 class="mt-4 mb-2 text-left">Alternatively, continue on your phone via <span class="text-blue-500">text message</span> or <span class="text-blue-500">email</span></h4>
          </div>
        </div>
      </div>
    </section>
  </section>
</template>

<script>
import { 
  MenuIcon,
  CameraIcon
 } from "vue-feather-icons";
export default {
  name: 'Home',
  data() {
    return {};
  },
  components: {
    MenuIcon,
    CameraIcon
  },
  props: {
    menuOpened: {
      type: Boolean,
      default: false
    },
    appliedProp: {
      type: Object,
    }
  },
  computed: {},
  watch: {},
  mounted() {},
};
</script>
